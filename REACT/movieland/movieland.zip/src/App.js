import React from "react";
import {Movie} from "./movie/Movie";

import './App.css';

  const App=()=> {
    
    return (
      <div>
        <Movie/>
      </div>
    );
  }

  export default App;